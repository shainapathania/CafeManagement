import React from "react";
import "./AddFood.css";
import { Container, Row, Col, Form } from "react-bootstrap";


export function foodCard(){
    return (
    <div className="card cards">
      <div className="card-body">
      <h5 className="card-title">Add Food</h5>
      
    </div>
        
    </div>
    )
}